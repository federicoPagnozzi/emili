
sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.1.xml/Objective ./1Objective
echo "$(tail -n +2 1Objective)" > 1Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.2.xml/Objective ./2Objective
echo "$(tail -n +2 2Objective)" > 2Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.3.xml/Objective ./3Objective
echo "$(tail -n +2 3Objective)" > 3Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.4.xml/Objective ./4Objective
echo "$(tail -n +2 4Objective)" > 4Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.5.xml/Objective ./5Objective
echo "$(tail -n +2 5Objective)" > 5Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.6.xml/Objective ./6Objective 
echo "$(tail -n +2 6Objective)" > 6Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.7.xml/Objective ./7Objective 
echo "$(tail -n +2 7Objective)" > 7Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.8.xml/Objective ./8Objective
echo "$(tail -n +2 8Objective)" > 8Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/Instance_V_1.9.xml/Objective ./9Objective
echo "$(tail -n +2 9Objective)" > 9Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/nstance_V_1.10.xml/Objective ./10Objective
echo "$(tail -n +2 10Objective)" > 10Objective

sshpass -p "lss0!gWT7" scp -r  afiscarelli@majorana.ulb.ac.be:/home/afiscarelli/MasterThesis2/Neighborhood/nstance_V_1.11.xml/Objective ./11Objective
echo "$(tail -n +2 11Objective)" > 11Objective
